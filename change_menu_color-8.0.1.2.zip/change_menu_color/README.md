# odoo-change-menu-color
Change color of Odoo 8.0 menu
