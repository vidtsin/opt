from odoo import api, fields, models, _

class PosOrderReturn(models.Model):
    _name = "pos.order.return"


