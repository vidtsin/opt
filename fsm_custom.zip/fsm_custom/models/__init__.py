from .import res_partner
from . import fields_project_task
from . import sale_order_fsm
