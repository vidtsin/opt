from ..base import ShopifyResource


class CarrierService(ShopifyResource):
    pass
