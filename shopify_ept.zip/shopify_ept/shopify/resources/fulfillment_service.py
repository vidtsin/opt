from ..base import ShopifyResource


class FulfillmentService(ShopifyResource):
    pass
