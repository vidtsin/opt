from ..base import ShopifyResource


class ProductSearchEngine(ShopifyResource):
    pass
