# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from . import emp_skill_line
from . import employee
from . import feedback
from . import task
from . import res_users
from . import zone_country_city_area
from . import task_type
from . import res_company
from . import project
from . import partner
