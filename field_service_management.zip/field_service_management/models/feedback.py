# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.
from odoo import fields, models

AVAILABLE_PRIORITIES = [
    ('1', 'Unhappy'),
    ('2', 'Good'),
    ('3', 'Average'),
    ('4', 'Satisfied'),
    ('5', 'Happy'),
    ('6', 'Very Happy')
]


class JobFeedback(models.Model):
    _name = 'job.feedback'
    _description = 'Job Feedback'
    _rec_name = 'partner_id'

    partner_id = fields.Many2one('res.partner',
                                 string='Customer',
                                 help="Author of the rating",
                                 required=True)
    rating = fields.Selection(AVAILABLE_PRIORITIES, "Rating", default='1')
    feedback = fields.Text('Feedback', help="Reason of the rating")
    task_id = fields.Many2one('project.task',
                              string='Job',
                              help="Task on which the rating is given.")
    user_id = fields.Many2one(
        related='task_id.user_id', relation='res.users', string='Serviceman',
        store=True)
    # selection_install = fields.Selection([('dishwasher', 'Dishwasher'), ('washer', 'Washer'), ('dryer', 'Dryer'),
    #                                         ('cooktop', 'Cooktop'),('range','Range'), ('downdraft','Downdraft'),
    #                                       ('ice_machine', 'Ice Machine'), ('refrigerator', 'Refrigerator'),
    #                                       ('freezer','Freezer'), ('hood','Hood'), ('microwave oven','Microwave/Oven'),
    #                                       ('other','Other')],string='Installation')
    #
    # dishwasher_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                        ('supply_live_connected', 'Supply live Connected'),
    #                                        ('checked_function', 'Checked Function'),
    #                                        ('operation_explained', 'Operation Explained'),
    #                                        ('drain_connected', 'Drain Connected'),
    #                                        ('tci', 'Toe Click Installed'),
    #                                        ('packing_material_removed', 'Packing Material Removed')],string='DISHWASHER')
    #
    # washer_install = fields.Selection([('appliance_secure','Appliance Secured'),('supply_live_connected', 'Supply line Connected'),
    #                                        ('checked_function', 'Checked Function'),('operation_explained', 'Operation Explained'),
    #                                        ('drain_connected', 'Drain Connected'),('shipping_struts_removed','Shipping Struts Removed'),
    #                                     ('packing_material_removed','Packing Material Removed')],
    #                                   string='WASHER')
    #
    # dryer_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                   ('supply_live_connected', 'Supply line Connected'),
    #                                        ('checked_function', 'Checked Function'),
    #                                   ('operation_explained', 'Operation Explained'),
    #                                        ('drain_connected', 'Drain Connected'),
    #                                   ('shipping_struts_removed','Shipping Struts Removed'),
    #                                     ('packing_material_removed','Packing Material Removed')], string='DRYER')
    #
    # cooktop_insatll = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                   ('electrical_connected', 'Electrical Connected'),
    #                                        ('gas_connected', 'Gas Connected'),
    #                                   ('operation_explained', 'Operation Explained'),
    #                                        ('all_bnr_ignite', 'All Burners Ignite'),
    #                                     ('packing_material_removed','Packing Material Removed'),
    #                                     ('grates_&_knob', 'Grates & Knob Present')], string='COOKTOP')
    #
    # range_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                   ('electrical_connected', 'Electrical Connected'),
    #                                        ('gas_connected', 'Gas Connected'),
    #                                   ('operation_explained', 'Operation Explained'),
    #                                        ('all_bnr_ignite', 'All Burners Ignite'),
    #                                     ('packing_material_removed','Packing Material Removed'),
    #                                     ('grates_&_knob', 'Grates & Knob Present')], string='RANGE')
    #
    # downdraft_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                       ('raise/lowers', 'Raise/Lowers'),
    #                                       ('remote_mounted', 'Remote Mounted'),
    #                                       ('filters_installed', 'Filters Installed'),
    #                                   ('electrical_connected', 'Electrical Connected'),
    #                                   ('operation_explained', 'Operation Explained'),
    #                                     ('packing_material_removed','Packing Material Removed')], string='DOWNDRAFT')
    #
    # ice_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                   ('electrical_connected', 'Electrical Connected'),
    #                                 ('supply_live_connected', 'Supply live Connected'),
    #                                 ('drain line connected', 'Drain Line Connected'),
    #                                        ('function properly', 'Functions Properly'),
    #                                     ('panel installed','Panel Installed'),
    #                                     ('pump working', 'Pump Working')], string='ICE MACHINE')
    #
    # refrigerator_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                   ('anti_tip_mounted', 'Anti Tip Mounted'),
    #                                 ('electrical line connected', 'Electrical Line Connected'),
    #                                 ('water line connected', 'Water Line Connected'),
    #                                     ('operation_explained', 'Operation Explained'),
    #                                     ('water purged','Water Purged'),
    #                                     ('ice_maker_on', 'Ice Maker On')], string='REFRIGERATOR')
    #
    # freezer_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                   ('anti_tip_mounted', 'Anti Tip Mounted'),
    #                                 ('electrical line connected', 'Electrical Line Connected'),
    #                                 ('water line connected', 'Water Line Connected'),
    #                                     ('operation_explained', 'Operation Explained'),
    #                                     ('water purged','Water Purged'),
    #                                     ('ice_maker_on', 'Ice Maker On')], string='FREEZER')
    #
    # hood_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                  ('electrical_connected', 'Electrical Connected'),
    #                                 ('duct connected & sealed', 'Duct Connected & Sealed'),
    #                                  ('function properly', 'Functions Properly'),
    #                                  ('packing_material_removed', 'Packing Material Removed'),
    #                                 ('grates installed','Grates Installed'),
    #                                     ('flow test', 'Flow Test')], string='HOOD')
    #
    # microwave_install = fields.Selection([('trim kit & open', 'Trim Kit Installed/Open Closes'),
    #                                     ('appliance_secure','Appliance Secured'),
    #                                  ('electrical_connected', 'Electrical Connected'),
    #                                 ('trim kit', 'Trim Kit Installed'),
    #                                  ('packing_material_removed', 'Packing Material Removed'),
    #                                       ('operation_explained', 'Operation Explained'),
    #                                       ('open closes', 'Opens/Closes'),
    #                                      ('function properly', 'Functions Properly')],string='Microwave/Oven')
    #
    # other_install = fields.Selection([('appliance_secure','Appliance Secured'),
    #                                  ('power water', 'Power/ Water'),
    #                                 ('trim kit', 'Trim Kit Installed'),
    #                                 ('operation_explained', 'Operation Explained'),
    #                                   ('packing_material_removed', 'Packing Material Removed')],string='OTHER')





