# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.
from odoo import fields, models


class ProjectTaskType(models.Model):
    _inherit = 'project.task.type'

    state = fields.Selection([('draft', 'New'),
                              ('pending', 'Pending'),
                              ('open', 'In Progress'),
                              ('done', 'Done'),
                              ('cancelled', 'Cancelled')],
                             string='State',
                             help="Process of Job.")
    auto_assign = fields.Boolean('Auto-assign to new project?', default=False)
